#ifndef __RTC_DS1307_H__
#define __RTC_DS1307_H__

#include "M031Series.h"

typedef struct 
{
	uint16_t u16Year;		// 2010 ~ 65535
	uint8_t u8Month;		// 1~12
	uint8_t u8Day;			// 1~28 or 1~29 or 1~30 or 1~ 31
	uint8_t u8DayOfWeek;	// 1 ~ 7
	uint8_t u8Hour;	 		// 0 ~ 23
	uint8_t u8Minute;		// 0 ~ 59
	uint8_t u8Second;		// 0 ~ 59
}Time_t;

typedef struct
{
	Time_t Now;
	
	// 0x00 - 0x03
	uint32_t u32LogPointer;
	
	// 0x04 - 0x05
	uint16_t u16LogSum;
	
	// 0x06 - 0x07
	uint16_t u16LogSumBackup;
		
	// 0x08 - 0x09
	uint16_t u16Value01;
	
	// 0x0a - 0x0b
	uint16_t u16Value02;
	
	// 0x0c - 0x0d
	uint16_t u16Value03;
	
	// 0x2A
	uint8_t u8InitCode;
} RTC_RAM;

void vSetRTC_Time(Time_t *);
void vGetRTC_Time(Time_t *);
void vRTC_WriteBytes(uint8_t u8StartAddress,uint8_t *pu8Bytes, uint8_t u8Len);
void vRTC_ReadBytes(uint8_t u8StartAddress, uint8_t *pu8Bytes, uint8_t u8Len);
// void vRTC_WriteEE_Byte(uint8_t u8Addr,uint8_t u8Data);
// void vRTC_ReadEE_Byte(uint8_t u8Addr,uint8_t u8Data);

void vRTC_ReadEE_Bytes(uint8_t u8Addr,uint8_t *u8Data, uint8_t u8Len);
void vRTC_WriteEE_Bytes(uint8_t u8Addr,uint8_t *u8Data, uint8_t u8Len);


void RTC_Initialize(void);
#endif 

